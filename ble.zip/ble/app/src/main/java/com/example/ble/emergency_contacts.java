package com.example.ble;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class emergency_contacts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);
    }
}